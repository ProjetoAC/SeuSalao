/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacotes;

/**
 *
 * @author vinicius
 */
public class Cliente {
    public int id_cliente;
    public int nr_telefone;
    public String ds_email;
    public String ds_endereco;
    public int ds_cpf;
    public int id_perfil;
    public String ds_nome;
}
